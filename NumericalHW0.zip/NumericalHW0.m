% Benjamin Baker
% Numerical HW 0

%% Problem 2.1
%  Write a program to compute the term am in the sequence {an}n≥0

a = 0;
b = 1;
x = n - 1;
n = input('input value for n');
for i = 1:n

    c = a + b;
    a = b;
    b = c;
end
for i = n:x

    c = a + b;
    a = b;
    b = c;

end

%% Problem 2.2
%  Write a program to use Laplace expansion (see its definition on page 2) to compute
%  the determinant of a matrix A ∈ Rn×n, where 1 ≤ n ≤ 10.

tic 
function detValue = laplaceDet(A)
    % Check if the input matrix A is square
    [m, n] = size(A);
    if m ~= n
        error('Matrix must be square.');
    end
    
    % Base case 1x1 matrix
    if m == 1
        detValue = A(1,1);
        return;
    end
    
    % Base case 2x2 matrix
    if m == 2
        detValue = A(1,1)*A(2,2) - A(1,2)*A(2,1);
        return;
    end

    
    detValue = 0;
    for col = 1:n
        % Create the minor matrix by removing the first row and current column
        minorMatrix = A(2:end, [1:col-1, col+1:end]);
        % Compute the cofactor and add to determinant
        cofactor = ((-1)^(1+col)) * A(1, col) * laplaceDet(minorMatrix);
        detValue = detValue + cofactor;
    end
 end
toc
